﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlareOn2
{
	class Program
	{
		static void Main(string[] args)
		{
			/*
			Console.WriteLine("Flareon Start End (inclusive)");
			if(args.Length!=2)
			{
				return;
			}

			int current = int.Parse(args[0]);
			int currentend = int.Parse(args[1]);
			while (current<= currentend)
			{
				Console.WriteLine($"Trying {current}...");
				Try(current);

				current += 1;
			}*/

			// uint[] key = new uint[] { 0x7c, 0x7f, 0x7e, 0x79 };
			uint[] key = new uint[] { 0x31, 0x73, 0x35, 0xB1 };
			byte[] key2 = new byte[] { 0x31, 0x73, 0x35, 0xB1 };

			int width = 480;
			byte[] source = new byte[]
			{
				0x47, 0x49, 0x46, 0x38, 0x39, 0x61,Convert.ToByte(width&255), Convert.ToByte(width>>8)
			};

			//Try(480);
			byte[] enc = Encrypt_Org(source, key2);
			byte[] enc2 = Encrypt(source, key);

			byte[] file = File.ReadAllBytes(@"e:\Documents\Projects\low-tech\Episodes\014-FLARE-ON_2019_10\best.gif.Mugatu");
			for (var i = 0; i < file.Length; i += 8)
			{
				if (i + 7 >= file.Length)
				{
					continue;
				}

				byte[] original = new byte[8];
				Array.Copy(file, i, original, 0, 8);
				byte[] decrypted = Decrypt(original, key);
				Array.Copy(decrypted, 0, file, i, 8);
			}
			File.WriteAllBytes("out.gif", file);


			//byte[] encrypted = Encrypt(source, key);
			// byte[] decrypted = Decrypt(encrypted, key);









			byte[] target = new byte[]
			{
				0x24, 0x8E, 0xB0, 0x50, 0xE8, 0xB2, 0x68, 0x6F
			};

			/*
			uint sum = 0;
			do
			{
				byte[] decrypted = Decrypt(target, key);
				if (decrypted[0] == 'G' && decrypted[1] == 'I' && decrypted[2] == 'F' && decrypted[3] == '8' && decrypted[4] == '9' && decrypted[5] == 'a')
				{
					Console.WriteLine(sum);
				}
				sum += 1;
			} while (sum != 0);
			Console.Read();*/
		}

		
		static void Try(int width)
		{
			byte[] source = new byte[]
			{
				0x47, 0x49, 0x46, 0x38, 0x39, 0x61,Convert.ToByte(width&255), Convert.ToByte(width>>8)
			};

			byte[] target = new byte[]
			{
				0x24, 0x8E, 0xB0, 0x50, 0xE8, 0xB2, 0x68, 0x6F
			};

			byte[] key = new byte[] { 0x31, 0x73, 0x35, 0xB1};

			byte[] result;
			do
			{
						result = Encrypt_Org(source, key);

				key[0] += 1;
				if (key[0] == 0)
				{
					key[1] += 1;
					if (key[1] == 0)
					{
						key[2] += 1;
						if (key[2] == 0)
						{
							key[3]++;
							if (key[3] == 0)
							{
								return;
							}
						}
					}
				}

			} while (
				result[0] != target[0] || result[1] != target[1] || result[2] != target[2] || result[3] != target[3] ||
				result[4] != target[4] || result[5] != target[5] || result[6] != target[6] || result[7] != target[7]);

			Console.WriteLine(BitConverter.ToString(key).Replace("-", ""));
			Console.Read();
		}
	

		static byte[] Encrypt_Org(byte[] input, byte[] key)
		{
			int ebp_p8 = 0x20;
			uint edi = BitConverter.ToUInt32(input, 0);
			uint ebx = BitConverter.ToUInt32(input, 4);
			uint esi = 0;

			while (ebp_p8 > 0)
			{
				uint eax = esi & 3;
				uint edx = key[eax];
				uint ecx = ebx;
				ecx = ecx << 4;
				eax = ebx;
				eax = eax >> 5;
				edx = edx + esi;
				ecx = ecx ^ eax;
				esi = esi - (uint)0x61c88647;
				ecx = ecx + ebx;
				ecx = ecx ^ edx;
				edi = edi + ecx;
				ecx = edi;
				eax = edi;
				eax = eax >> 5;
				ecx = ecx << 4;
				ecx = ecx ^ eax;
				eax = esi;
				eax = eax >> 0xb;
				ecx = ecx + edi;
				eax = eax & 3;
				eax = key[eax];
				eax = eax + esi;
				ecx = ecx ^ eax;
				ebx = ebx + ecx;

				ebp_p8 -= 1;
			}

			byte[] output = new byte[8];
			Array.Copy(BitConverter.GetBytes(edi), output, 4);
			Array.Copy(BitConverter.GetBytes(ebx), 0, output, 4, 4);

			return output;
		}


		private static byte[] Encrypt(byte[] block, uint[] key)
		{
			uint i;
			uint delta = 0x9E3779B9;

			uint v0 = BitConverter.ToUInt32(block, 0);
			uint v1 = BitConverter.ToUInt32(block, 4);
			uint sum = 0;

			for (i = 0; i < 32; i++)
			{
				v0 += (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + key[sum & 3]);
				sum += delta;
				v1 += (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum >> 11) & 3]);
			}

			byte[] result = new byte[8];
			Array.Copy(BitConverter.GetBytes(v0), result, 4);
			Array.Copy(BitConverter.GetBytes(v1), 0, result, 4, 4);
			return result;
		}


		private static byte[] Decrypt(byte[] block, uint[] key)
		{
			uint i;
			uint delta = 0x9E3779B9;

			uint v0 = BitConverter.ToUInt32(block, 0);
			uint v1 = BitConverter.ToUInt32(block, 4);

			uint sum = delta * 32;
			for (i = 0; i < 32; i++)
			{
				v1 -= (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sum + key[(sum >> 11) & 3]);
				sum -= delta;
				v0 -= (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sum + key[sum & 3]);
			}

			byte[] result = new byte[8];
			Array.Copy(BitConverter.GetBytes(v0), result, 4);
			Array.Copy(BitConverter.GetBytes(v1), 0, result, 4, 4);
			return result;
		}
	}
}
