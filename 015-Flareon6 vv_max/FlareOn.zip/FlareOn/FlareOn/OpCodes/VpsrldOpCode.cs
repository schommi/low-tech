﻿using System;

namespace FlareOn.OpCodes
{
	internal class VpsrldOpCode : OpCode
	{
		public override int Parameters => 3;

		public override void Invoke(VM vm, byte[] parameters)
		{
			byte[] result = new byte[0x20];

			for (int dword = 0; dword < 8; dword++)
			{
				uint value = BitConverter.ToUInt32(vm.Registers[parameters[1]].Bytes, dword * 4);
				value = value >> parameters[2];
				Array.Copy(BitConverter.GetBytes(value), 0, result, dword * 4, 4);
			}

			vm.Registers[parameters[0]].Set(vm, new byte[] { parameters[1], parameters[2] }, result);
		}
	}
}