﻿namespace FlareOn.OpCodes
{
	internal class ClearOpCode : OpCode
	{
		public override int Parameters => 0;

		public override void Invoke(VM vm, byte[] parameters)
		{
			for (int i = 0; i < 0x20; i++)
			{
				vm.Registers[i].Clear();
			}
		}

		public override bool IsModifier => false;
	}
}