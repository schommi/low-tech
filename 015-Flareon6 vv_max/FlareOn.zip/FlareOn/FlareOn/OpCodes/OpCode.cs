﻿namespace FlareOn.OpCodes
{
	internal abstract class OpCode
	{
		public abstract int Parameters { get; }

		public abstract void Invoke(VM vm, byte[] parameters);

		public virtual bool IsModifier => true;
	}
}
