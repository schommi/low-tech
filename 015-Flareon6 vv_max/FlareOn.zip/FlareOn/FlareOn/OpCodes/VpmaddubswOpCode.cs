﻿using System;

namespace FlareOn.OpCodes
{
	internal class VpmaddubswOpCode : OpCode
	{
		public override int Parameters => 3;

		public override void Invoke(VM vm, byte[] parameters)
		{
			byte[] result = new byte[0x20];
			for (int i = 0; i < 0x20; i += 2)
			{
				// Handle sign?
				short op1 = vm.Registers[parameters[1]].Bytes[i];
				op1 *= vm.Registers[parameters[2]].Bytes[i];
				short op2 = vm.Registers[parameters[1]].Bytes[i + 1];
				op2 *= vm.Registers[parameters[2]].Bytes[i + 1];

				Array.Copy(BitConverter.GetBytes(op1 + op2), 0, result, i, 2);
			}

			vm.Registers[parameters[0]].Set(vm, new byte[] { parameters[1], parameters[2] }, result);
		}
	}
}