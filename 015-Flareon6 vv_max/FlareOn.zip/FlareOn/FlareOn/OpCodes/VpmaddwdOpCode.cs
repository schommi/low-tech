﻿using System;

namespace FlareOn.OpCodes
{
	internal class VpmaddwdOpCode : OpCode
	{
		public override int Parameters => 3;

		public override void Invoke(VM vm, byte[] parameters)
		{
			byte[] result = new byte[0x20];
			for (int i = 0; i < 0x20; i += 4)
			{
				int op1 = BitConverter.ToUInt16(vm.Registers[parameters[1]].Bytes, i) * BitConverter.ToUInt16(vm.Registers[parameters[2]].Bytes, i);
				int op2 = BitConverter.ToUInt16(vm.Registers[parameters[1]].Bytes, i + 2) * BitConverter.ToUInt16(vm.Registers[parameters[2]].Bytes, i+2);
				Array.Copy(BitConverter.GetBytes(op1 + op2), 0, result, i, 4);
			}

			vm.Registers[parameters[0]].Set(vm, new byte[] { parameters[1], parameters[2] }, result);
		}
	}
}