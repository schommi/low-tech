﻿using System;

namespace FlareOn.OpCodes
{
	internal class VpaddbOpCode : OpCode
	{
		public override int Parameters => 3;

		public override void Invoke(VM vm, byte[] parameters)
		{
			byte[] result = new byte[0x20];
			for (int i = 0; i < 0x20; i++)
			{
				result[i] = (byte)(vm.Registers[parameters[2]].Bytes[i] + vm.Registers[parameters[1]].Bytes[i]);
			}

			vm.Registers[parameters[0]].Set(vm, new byte[] { parameters[1], parameters[2] }, result);
		}
	}
}