﻿using System;

namespace FlareOn.OpCodes
{
	internal class VpxorOpCode : OpCode
	{
		public override int Parameters => 3;

		public override void Invoke(VM vm, byte[] parameters)
		{
			byte[] result = new byte[0x20];
			byte[] word = new byte[4];

			for (int i = 0; i < 0x20; i += 4)
			{
				uint value =
					BitConverter.ToUInt32(vm.Registers[parameters[1]].Bytes, i) ^
					BitConverter.ToUInt32(vm.Registers[parameters[2]].Bytes, i);

				Array.Copy(BitConverter.GetBytes(value), 0, result, i, 4);
			}

			vm.Registers[parameters[0]].Set(vm, new byte[] { parameters[1], parameters[2] }, result);
		}
	}
}
