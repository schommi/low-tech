﻿using System;

namespace FlareOn.OpCodes
{
	internal class VpshufbOpCode : OpCode
	{
		public override int Parameters => 3;

		public override void Invoke(VM vm, byte[] parameters)
		{
			byte[] result = new byte[0x20];
			for (int j = 0; j < 2; j++)
			{
				for (int i = 0; i < 0x10; i++)
				{
					int index = j * 0x10 + vm.Registers[parameters[2]].Bytes[(j * 0x10 + i)] & 0xf;
					result[j * 0x10 + i] = vm.Registers[parameters[1]].Bytes[j*0x10 + index];
				}
			}

			vm.Registers[parameters[0]].Set(vm, new byte[] { parameters[1], parameters[2] }, result);
		}
	}
}
