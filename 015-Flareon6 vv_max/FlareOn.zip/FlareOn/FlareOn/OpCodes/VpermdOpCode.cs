﻿using System;

namespace FlareOn.OpCodes
{
	internal class VpermdOpCode : OpCode
	{
		public override int Parameters => 3;

		public override void Invoke(VM vm, byte[] parameters)
		{
			byte[] result = new byte[0x20];

			for (int dword = 0; dword < 8; dword++)
			{
				uint index = BitConverter.ToUInt32(vm.Registers[parameters[2]].Bytes, dword * 4);
				if (index == 0xffffffff)
				{
					Array.Copy(new byte[] { 0, 0, 0, 0 }, 0, result, dword * 4, 4);
				}
				else
				{
					Array.Copy(vm.Registers[parameters[1]].Bytes, index * 4, result, dword * 4, 4);
				}
			}

			vm.Registers[parameters[0]].Set(vm, new byte[] { parameters[1], parameters[2] }, result);
		}
	}
}