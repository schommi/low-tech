﻿using System.Linq;

namespace FlareOn.OpCodes
{
	internal class LoadOpCode : OpCode
	{
		public override int Parameters => 0x21;
		int m_Counter = 0;

		public override void Invoke(VM vm, byte[] parameters)
		{
			byte[] sources;
			switch (m_Counter)
			{
				case 0:
					sources = new byte[] { 0xfe };
					break;
				case 1:
					sources = new byte[] { 0xff };
					break;
				default:
					sources = new byte[0];
					break;
			}

			vm.Registers[parameters[0]].Set(vm, sources, parameters.Skip(1));
			m_Counter++;
		}
	}
}