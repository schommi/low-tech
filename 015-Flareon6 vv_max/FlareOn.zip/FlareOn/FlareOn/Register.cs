﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FlareOn
{
	internal class Register
	{
		public byte[] Bytes { get; } = new byte[0x20];

		public bool HasCode1 { get; private set; }

		public bool HasCode2 { get; private set; }

		public void Clear()
		{
			Array.Clear(Bytes, 0, 0x20);
		}

		public void Set(VM vm, byte[] sources, IEnumerable<byte> value)
		{
			if (sources.Any(s => s == 0xfe))
			{
				HasCode1 = true;
			}
			else if (sources.Any(s => s == 0xff))
			{
				HasCode2 = true;
			}
			else
			{
				HasCode1 = sources.Any(s => vm.Registers[s].HasCode1);
				HasCode2 = sources.Any(s => vm.Registers[s].HasCode2);
			}

			int index = 0;
			foreach (byte byt in value)
			{
				Bytes[index++] = byt;
			}

			if (index != 0x20)
			{
				throw new ArgumentException($"Invalid parameter count, 0x20 expected, {index} passed.");
			}
		}

		public override string ToString()
		{
			return "(" + (HasCode1 ? "1" : " ") + (HasCode2 ? "2" : " ") + ")" + BitConverter.ToString(Bytes).Replace("-", string.Empty);
		}
	}
}