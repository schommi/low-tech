﻿using FlareOn.OpCodes;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace FlareOn
{
	internal class VM
	{
		private readonly byte[] m_Code;
		private StringBuilder m_Log = new StringBuilder();

		private readonly Dictionary<byte, OpCode> m_OpCodes = new Dictionary<byte, OpCode>
		{
			{ 0x00, new ClearOpCode() },
			{ 0x01, new VpmaddubswOpCode() },
			{ 0x02, new VpmaddwdOpCode() },
			{ 0x03, new VpxorOpCode() },
			{ 0x04, new VporOpCode() },
			{ 0x05, new VpandOpCode() },
			{ 0x07, new VpaddbOpCode() },
			{ 0x0b, new VpadddOpCode() },
			{ 0x11, new LoadOpCode() },
			{ 0x12, new VpsrldOpCode() },
			{ 0x13, new VpslldOpCode() },
			{ 0x14, new VpshufbOpCode() },
			{ 0x15, new VpermdOpCode() },
			{ 0x16, new VpcmpeqbOpCode() }
		};

		public VM(byte[] code)
		{
			m_Code = code;
			IP = 0;
			Registers = new Register[0x20];
			for (int i = 0; i < 0x20; i++)
			{
				Registers[i] = new Register();
			}
		}

		public int IP { get; private set; }

		public Register[] Registers { get; }

		public bool Next()
		{
			OpCode opCode = GetOpCode();
			if (opCode == null)
			{
				return false;
			}

			byte[] parameters = GetParameters(opCode.Parameters);

			if (opCode.IsModifier)
			{
				if (opCode.Parameters == 3)
				{
					m_Log.AppendLine($"{IP.ToString("x4")}:{parameters[0].ToString("x2")} = {opCode.GetType().Name.Replace("OpCode", "")} ({parameters[1].ToString("x2")}, {parameters[2].ToString("x2")})");
				}
				else
				{
					m_Log.AppendLine($"{IP.ToString("x4")}:{parameters[0].ToString("x2")} = {opCode.GetType().Name.Replace("OpCode", "")} ({BitConverter.ToString(parameters.Skip(1).ToArray()).Replace("-", "")})");
				}
			}

			opCode.Invoke(this, parameters);
			IP += opCode.Parameters + 1;
			return true;
		}

		public string Peek()
		{
			OpCode opCode = GetOpCode();
			string displayOpCode;
			string parameters;
			if (opCode != null)
			{
				displayOpCode = opCode.GetType().Name.Substring(0, opCode.GetType().Name.Length - "OpCode".Length);
				parameters = BitConverter.ToString(GetParameters(opCode.Parameters)).Replace("-", " ");
			}
			else
			{
				displayOpCode = "Exit";
				parameters = "";
			}

			return $"{displayOpCode} {parameters}";
		}

		public void Dump(string fileName)
		{
			using (FileStream file = File.OpenWrite(fileName))
			{
				for (int i = 0; i < 0x20; i++)
				{
					file.Write(Registers[i].Bytes, 0, 0x20);
				}
			}
		}

		public void Log(string fileName)
		{
			File.WriteAllText(fileName, m_Log.ToString());
		}

		private OpCode GetOpCode()
		{
			if (m_Code[IP] == 0xff)
			{
				return null;
			}

			OpCode opCode;
			if (!m_OpCodes.TryGetValue(m_Code[IP], out opCode))
			{
				throw new InvalidOperationException($"Unknown OpCode {m_Code[IP].ToString("2x")} encountered at {IP.ToString("2x")}.");
			}

			return opCode;
		}

		private byte[] GetParameters(int count)
		{
			byte[] parameters = new byte[count];
			Array.Copy(m_Code, IP + 1, parameters, 0, count);
			return parameters;
		}

	}
}
