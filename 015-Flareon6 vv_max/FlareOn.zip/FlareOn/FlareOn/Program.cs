﻿using System;
using System.IO;
using System.Text;
using System.Threading;

namespace FlareOn
{
	class Program
	{
		static void Main(string[] args)
		{
			byte[] originalBytes = File.ReadAllBytes("vm.bin");
			byte[] copiedBytes = new byte[originalBytes.Length];


			/*
			int charOffset = int.Parse(args[0]); // *4
			int byteOffset = int.Parse(args[1]); // *3
			string allowedChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_0123456789";

			foreach (char c1 in allowedChars)
			{
				foreach (char c2 in allowedChars)
				{
					foreach (char c3 in allowedChars)
					{
						foreach (char c4 in allowedChars)
						{
							Array.Copy(originalBytes, copiedBytes, originalBytes.Length);
							copiedBytes[charOffset + 0x25] = (byte)c1;
							copiedBytes[charOffset + 0x26] = (byte)c2;
							copiedBytes[charOffset + 0x27] = (byte)c3;
							copiedBytes[charOffset + 0x28] = (byte)c4;

							VM vm = new VM(copiedBytes);
							while (vm.Next()) ;

							if (vm.Registers[2].Bytes[byteOffset + 0] == vm.Registers[0x14].Bytes[byteOffset + 0] &&
								vm.Registers[2].Bytes[byteOffset + 1] == vm.Registers[0x14].Bytes[byteOffset + 1] &&
								vm.Registers[2].Bytes[byteOffset + 2] == vm.Registers[0x14].Bytes[byteOffset + 2])
							{
								Console.WriteLine($"Match: {c1}{c2}{c3}{c4}");
								Console.WriteLine(vm.Registers[2]);
								//Console.ReadLine();
							}



							//Console.WriteLine($" 2: {vm.Registers[2]}");
							//Console.WriteLine($"14: {vm.Registers[0x14]}");
						}

					}
				}

			}*/

			Console.ReadKey();
			VM vm = new VM(originalBytes);

			do
			{
				Console.Clear();
				Console.WriteLine($"IP  : {vm.IP.ToString("x2")}");
				Console.WriteLine($"Next: {vm.Peek()}");

				for (int i = 0; i < 0x20; i++)
				{
					Console.WriteLine($"R{i.ToString("x2")}:{vm.Registers[i]}");
				}

				//Console.ReadKey();
				//Thread.Sleep(500);

			} while (vm.Next());
			vm.Dump("local-end.bin");
			vm.Log("commands.txt");
			Console.ReadKey();
		}

		
	}
}

