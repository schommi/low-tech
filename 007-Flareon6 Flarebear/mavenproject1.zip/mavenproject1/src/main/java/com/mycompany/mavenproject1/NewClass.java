/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Collection;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 *
 * 
 */
public class NewClass {
    public static void main(String[] args) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, InvalidAlgorithmParameterException, BadPaddingException {
        String pwd = getPassword()+""; // flareflareflareflare*BEARBEARBEARBEARBEARBEARBEARBEAR+yeahyeah
        byte[] file1Content = Files.readAllBytes(Paths.get("C:\\Users\\andre_000\\Desktop\\ecstatic"));
        byte[] decryptedFile1Content = decrypt(pwd, file1Content);
        Files.write(Paths.get("C:\\Users\\andre_000\\Desktop\\ecstatic.png"), decryptedFile1Content);

        byte[] file2Content = Files.readAllBytes(Paths.get("C:\\Users\\andre_000\\Desktop\\ecstatic2"));
        byte[] decryptedFile2Content =decrypt(pwd, file2Content);
        Files.write(Paths.get("C:\\Users\\andre_000\\Desktop\\ecstatic2.png"), decryptedFile2Content);
    }
    
    private static final String getPassword() {
        String str;
        int stat = 8; // getStat('f');
        int stat2 = 4; //getStat('p');
        int stat3 = 2; // getStat('c');
        String str2 = "*";
        String str3 = "&";
        String str4 = "@";
        String str5 = "#";
        String str6 = "+";
        String str7 = "$";
        String str8 = "_";
        String str9 = "";
        switch (stat % 9) {
            case 0:
                str = str8;
                break;
            case 1:
                str = "-";
                break;
            case 2:
                str = str7;
                break;
            case 3:
                str = str6;
                break;
            case 4:
                str = "!";
                break;
            case 5:
                str = str5;
                break;
            case 6:
                str = str4;
                break;
            case 7:
                str = str3;
                break;
            case 8:
                str = str2;
                break;
            default:
                str = str9;
                break;
        }
        switch (stat3 % 7) {
            case 0:
                str2 = str7;
                break;
            case 1:
                str2 = str8;
                break;
            case 2:
                str2 = str6;
                break;
            case 3:
                str2 = str5;
                break;
            case 4:
                str2 = str3;
                break;
            case 5:
                break;
            case 6:
                str2 = str4;
                break;
            default:
                str2 = str9;
                break;
        }
        String repeat = repeat("flare", stat / stat3);
        String repeat2 = repeat(rotN("bear", stat * stat2), stat2 * 2);
        String repeat3 = repeat("yeah", stat3);
        StringBuilder sb = new StringBuilder();
        sb.append(repeat);
        sb.append(str);
        sb.append(repeat2);
        sb.append(str2);
        sb.append(repeat3);
        return sb.toString();
    }
    
    private static final byte[] decrypt(String str, byte[] bArr) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, InvalidAlgorithmParameterException, BadPaddingException {
        String str2 = "UTF-8";
        Charset forName = Charset.forName(str2);
        String str3 = "Charset.forName(charsetName)";
        byte[] bytes = "pawsitive_vibes!".getBytes(forName);
        String str4 = "(this as java.lang.String).getBytes(charset)";
        IvParameterSpec ivParameterSpec = new IvParameterSpec(bytes);
        char[] charArray = str.toCharArray();
        Charset forName2 = Charset.forName(str2);
        byte[] bytes2 = "NaClNaClNaCl".getBytes(forName2);
        SecretKey generateSecret = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(new PBEKeySpec(charArray, bytes2, 1234, 256));
        SecretKeySpec secretKeySpec = new SecretKeySpec(generateSecret.getEncoded(), "AES");
        Cipher instance = Cipher.getInstance("AES/CBC/PKCS5Padding");
        instance.init(2, secretKeySpec, ivParameterSpec);
        byte[] doFinal = instance.doFinal(bArr);
        return doFinal;
    }

    private static final String repeat(CharSequence charSequence, int i) {
        int i2 = 1;
        if (i >= 0) {
            String str = "";
            if (i == 0) {
                return str;
            }
            if (i == 1) {
                return charSequence.toString();
            }
            int length = charSequence.length();
            if (length == 0) {
                return str;
            }
            if (length != 1) {
                StringBuilder sb = new StringBuilder(charSequence.length() * i);
                if (1 <= i) {
                    while (true) {
                        sb.append(charSequence);
                        if (i2 == i) {
                            break;
                        }
                        i2++;
                    }
                }
                String sb2 = sb.toString();
                return sb2;
            }
            char charAt = charSequence.charAt(0);
            char[] cArr = new char[i];
            int length2 = cArr.length;
            for (int i3 = 0; i3 < length2; i3++) {
                cArr[i3] = charAt;
            }
            return new String(cArr);
        }
        
        StringBuilder sb3 = new StringBuilder();
        sb3.append("Count 'n' must be non-negative, but was ");
        sb3.append(i);
        sb3.append('.');
        throw new IllegalArgumentException(sb3.toString().toString());
    }
    
    private static final String rotN(String str, int i) {
        CharSequence charSequence = str;
        StringBuilder builder = new StringBuilder();
        for (int i2 = 0; i2 < charSequence.length(); i2++) {
            char charAt = charSequence.charAt(i2);
            if (Character.isLowerCase(charAt)) {
                charAt = (char) (charAt + i);
                if (charAt > 'z') {
                    charAt = (char) (charAt - (i * 2));
                }
            }
            builder.append(charAt);
        }
        return builder.toString();
    }
}
