﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
	/// <summary>
	/// Interaktionslogik für MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private byte[] key = new byte[]
		{
			0x79,
			0x5a,
			0xb8,
			0xbc,
			0xec,
			0xd3,
			0xdf,
			0xdd,
			0x99,
			0xa5,
			0xb6,
			0xac,
			0x15,
			0x36,
			0x85,
			0x8d,
			0x09,
			0x08,
			0x77,
			0x52,
			0x4d,
			0x71,
			0x54,
			0x7d,
			0xa7,
			0xa7,
			0x08,
			0x16,
			0xfd,
			0xd7
		};

		private string valid_characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789";

		private TextBox[] firstCharTextBoxes = new TextBox[15];
		private TextBox[] outputTextBoxes = new TextBox[30];

		public MainWindow()
		{
			InitializeComponent();

			for (int i = 0; i < 30; i++)
			{
				TextBox codeTextbox = new TextBox
				{
					Text = key[i].ToString("x2"),
					IsReadOnly = true
				};

				codeTextbox.SetValue(Grid.ColumnProperty, i);
				codeTextbox.SetValue(Grid.RowProperty, 1);

				Grid.Children.Add(codeTextbox);

				TextBox outputTextbox = new TextBox
				{
					IsReadOnly = true
				};

				outputTextbox.SetValue(Grid.ColumnProperty, i);
				outputTextbox.SetValue(Grid.RowProperty, 5);

				outputTextBoxes[i] = outputTextbox;
				Grid.Children.Add(outputTextbox);
			}

			for (int i = 0; i < 15; i++)
			{
				int index = i;

				TextBox firstCharTextbox = new TextBox
				{
					Text = "a"
				};

				firstCharTextbox.SetValue(Grid.ColumnProperty, i * 2);
				firstCharTextbox.SetValue(Grid.RowProperty, 3);

				firstCharTextBoxes[i] = firstCharTextbox;

				firstCharTextbox.KeyUp += (sender, e) =>
				{
					string currentValue = firstCharTextbox.Text;
					if (!string.IsNullOrEmpty(currentValue) && currentValue.Length == 1)
					{
						char targetChar = currentValue[0];
						int targetCode = targetChar ^ key[index * 2];

						outputTextBoxes[index * 2].Text = Convert.ToChar((key[index * 2] ^ targetCode)).ToString();
						outputTextBoxes[index * 2 + 1].Text = Convert.ToChar((key[index * 2 + 1] ^ targetCode)).ToString();
					}

					string fullText = string.Concat(outputTextBoxes.Select(ot => ot.Text));
					FullText.Text = fullText;
				};

				Grid.Children.Add(firstCharTextbox);

				Button nextButton = new Button
				{
					Content = ">>"
				};

				nextButton.Click += (sender, e) =>
				{
					string currentValue = firstCharTextbox.Text;
					char current_char;
					int currentValueIndex = valid_characters.IndexOf(currentValue);
					if(currentValueIndex + 1>=valid_characters.Length)
					{
						current_char = valid_characters[0];
					}
					else
					{
						current_char = valid_characters[currentValueIndex + 1];
					}

					char targetChar = currentValue[0];
					int targetCode = targetChar ^ key[index * 2];

					firstCharTextBoxes[index].Text = current_char.ToString();
					outputTextBoxes[index * 2].Text = Convert.ToChar((key[index * 2] ^ targetCode)).ToString();
					outputTextBoxes[index * 2 + 1].Text = Convert.ToChar((key[index * 2 + 1] ^ targetCode)).ToString();

					string fullText = string.Concat(outputTextBoxes.Select(ot => ot.Text));
					FullText.Text = fullText;
				};

				nextButton.SetValue(Grid.ColumnProperty, i * 2 + 1);
				nextButton.SetValue(Grid.RowProperty, 3);

				Grid.Children.Add(nextButton);
			}
		}
	}
}